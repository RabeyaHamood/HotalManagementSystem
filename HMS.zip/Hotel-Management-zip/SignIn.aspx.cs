﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubs_Click(object sender, EventArgs e)
    {
        DataClass myclass = new DataClass();
        string _name = txtname.Text;
        string _email = txtemail.Text;
        string _contact = txtcontact.Text;
        string _pwd = txtpwd.Text;
        string _rpwd = txtpwdre.Text;

      string _DataFields="name" + "email , contact" + "password";
       string Values = "'" + _name + "','" + _email + "','" + _contact + "','" + _pwd + "'',";
        string Result = myclass.InsertIntoDataBase("tblReg", _DataFields, _Values);
        lblmsg.Text = Result;
    }
}