﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace j2
{
    public partial class Join2 : Form
    {
        public Join2()
        {
            InitializeComponent();
        }

        private void Join2_Load(object sender, EventArgs e)
        {

        }
    }
}
