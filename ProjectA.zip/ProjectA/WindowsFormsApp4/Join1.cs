﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;


namespace j1
{
    public partial class Join1 : Form
    {
        public Join1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source = LAPTOP-085RGBDL\SQLEXPRESS; Initial Catalog = ProjectA;Integrated Security = True; MultipleActiveResultSets = True");


        private void Join1_Load(object sender, EventArgs e)
        {

        }
        private void Display_Data()
        {

            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "(SELECT Project.Description , Project.Title , Advisor.Designation , Advisor.Salary from Project join Advisor ON Project.Id = Advisor.Id) ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Display_Data();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Document doc = new Document(PageSize.A4);
           // var output = new FileStream(SaveFileDialog.MapPath("MyFirstPDF.pdf"), FileMode.Create);
            //var writer = PdfWriter.GetInstance(doc, output);


            doc.Open();


           // var logo = iTextSharp.text.Image.GetInstance(Server.MapPath("~/ABsIS_Logo.jpg"));
           // logo.SetAbsolutePosition(430, 770);
           // logo.ScaleAbsoluteHeight(30);
           // logo.ScaleAbsoluteWidth(70);
           // doc.Add(logo);

            PdfPTable table1 = new PdfPTable(2);
            table1.DefaultCell.Border = 0;
            table1.WidthPercentage = 80;


            PdfPCell cell11 = new PdfPCell();
            cell11.Colspan = 1;
            cell11.AddElement(new Paragraph("datagridview1"));

            


            cell11.VerticalAlignment = Element.ALIGN_LEFT;

            PdfPCell cell12 = new PdfPCell();


            cell12.VerticalAlignment = Element.ALIGN_CENTER;
            table1.AddCell(cell11);

            table1.AddCell(cell12);



        }
    }
}
