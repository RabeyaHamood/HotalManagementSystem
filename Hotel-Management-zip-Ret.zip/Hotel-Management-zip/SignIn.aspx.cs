﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
       
    }

    protected void btnsubs_Click(object sender, EventArgs e)
    {
        AJ_DataClass ajdbClass = new AJ_DataClass();
        string _name = txtname.Text;
        
        string _email = txtemail.Text;
      
        string _contact = txtcon.Text;
        string _gender = cboGender.SelectedValue;
        string _age = txtage.Text;
        string _pwd = txtpwd.Text;
        string _rpwd = txtpwdre.Text;

        string _DataFields = "name,email,gender,contact,age,password";
        string _Values = "'" + _name + "','" + _email + "','" +
                 _gender + "','" + _age + "','" + _contact + "','" + _pwd + "'" ;
        string Result = ajdbClass.InsertIntoDatabase("tblReg", _DataFields, _Values);
        lblmsg.Text = Result;
    }
}