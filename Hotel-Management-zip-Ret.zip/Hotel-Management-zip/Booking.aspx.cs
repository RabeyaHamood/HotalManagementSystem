﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Booking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        AJ_DataClass ajdbClass = new AJ_DataClass();
        DataSet ds = new DataSet();

        if (!IsPostBack)
        {
            ds = ajdbClass.GetRecords("Room", "select * from Room");
           cborooms.DataSource = ds.Tables[0];
            cborooms.DataValueField = "Roomid";
            cborooms.DataTextField = "RoomName";
            cborooms.DataBind();
        }
        
    }

    protected void btnsubs_Click(object sender, EventArgs e)
    {  // Haaww .... tum nay apni db class Add krdi ? 


        AJ_DataClass ajdbClass = new AJ_DataClass();
        string _name = txtname.Text;
        string _email = txtemail.Text;
        string _phone = txtphone.Text;
        string _price = txtprice.Text;
        string _status = txtstatus.Text;
        string _StartDate = txtSdate.Text;
        string _EndDate = txtEdate.Text;

        string _DataFields = "RoomId, ReName, ReEmail, RePhone,RePaid, ReStatus,ReStart,  ReEnd";
        string _Values ="'" + cborooms.SelectedValue + "','" + _name + "','" + _email + "','" +
             _phone  + "','" + _price  + "','" + _status + "','" + _StartDate + "','"
           + _EndDate + "'";
        string Result = ajdbClass.InsertIntoDatabase("Reservation1"  , _DataFields, _Values);
      lblmsg.Text = Result;
    }
}